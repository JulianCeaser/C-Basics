#ifndef MEAN_H_INCLUDED
#define MEAN_H_INCLUDED


double compute_mean(float *A,int n);
double compute_sample_var(double mean, float *A, int n);

#endif

