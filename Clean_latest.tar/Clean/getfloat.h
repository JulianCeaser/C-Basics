#ifndef GETFLOAT_H_INCLUDED
#define GETFLOAT_H_INCLUDED
 
#include <stdio.h>


/* getfloat:  get next float from input into *pn */
int getfloat(FILE *stream, float *pn);

#endif
